package book.ch4;

public class ForTest {

	public static void main(String[] args) {
		for(int i=1;i<=3;i=i+1) {
			if(i%2==0) {
				System.out.println(i);				
			}
		}
	}

}