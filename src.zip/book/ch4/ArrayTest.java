package book.ch4;

public class ArrayTest {

	public static void main(String[] args) {
		int is[]=new int[3];//한번에 방이 3개 생김
		is [0]=1;
		is [1]=2;
		is [2]=3;
		double ds[]=new double[1];//방이 1개 생김
		for(int j=0;j<3;j++) {//j는 0부터 세기 때문에 3개를 셀 때 j<3으로 한다.
			   				//배열은 0부터 9까지가 기본
			System.out.println(is[j]);
		}
			
			

	}
		
}		
	

