package book.ch2;

public class Quiz3 {

	public static void main(String[] args) {
//더하기 연산자는 문자열과 숫자가 만났을 경우에는 덧셈의 역할이 아니라 
//문자열을 붙여서 출력해준다.		
		System.out.println(1+"2");//?
		System.out.println("1"+2);//?
		System.out.println(1+2);//?
		System.out.println("1"+"2");//?
	}

}