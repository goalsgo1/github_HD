package book.ch3;

public class P81_1 {

	public static void main(String[] args) {
		char ch=65;
		System.out.println(ch);
		System.out.println("Hello".charAt(2));
	}

}
