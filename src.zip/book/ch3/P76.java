package book.ch3;

public class P76 {

	public static void main(String[] args) {
		if(1==1) {
			System.out.println("네===>"+(5==5));
		}
		if(1!=1) {
			 System.out.println("네");
		}else {
			System.out.println("1과 1은 다르지 않아요==> 아니오"+(3!=3));			
		}

	}

}