package ocjp.basic;

public class Q29 {
	
	public static void main(String[] args) {

		int[] x= {1, 2, 3, 4, 5};
		int y[]= x;
		System.out.println(y[2]);
	}
}
